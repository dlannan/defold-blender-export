
-- --------------------------------------------------------------------------------

local ffi = require("ffi")
local bit = require("bit")
local lshift, rshift, band, bor = bit.lshift, bit.rshift, bit.band, bit.bor

-- --------------------------------------------------------------------------------
--[[
	Source: https://github.com/miloyip/svpng
	License: BSD-3-Clause License

/*!
    \brief Save a RGB/RGBA image in PNG format.
    \param SVPNG_OUTPUT Output stream (by default using file descriptor).
    \param w Width of the image. (<16383)
    \param h Height of the image.
    \param img Image pixel data in 24-bit RGB or 32-bit RGBA format.
    \param mode Whether the image is 3 or 4 channel (4 channel is alpha).
*/
]]--
local bt = string.byte

local t = {
	0x00, 0x1db71064, 0x3b6e20c8, 0x26d930ac, 0x76dc4190, 0x6b6b51f4, 0x4db26158, 0x5005713c,
    -- /* CRC32 Table */    
	0xedb88320, 0xf00f9344, 0xd6d6a3e8, 0xcb61b38c, 0x9b64c2b0, 0x86d3d2d4, 0xa00ae278, 0xbdbdf21c
}

local function svpng(fh, w, h, img, mode) 
	
	local a = ffi.new("uint32_t[1]")
	a[0] = 1
	local b = ffi.new("uint32_t[1]")
	b[0] = 0
	local c = ffi.new("uint32_t[1]")
	local p = ffi.new("uint16_t[1]")
	p[0] = w * mode + 1	  -- mode must be 3 or 4
	local x, y, i = 0, 0, 0   -- /* ADLER-a, ADLER-b, CRC, pitch */

	local function SVPNG_PUT(u) fh:write(string.char(u)) end
	local function SVPNG_U8A( ua, l )
		for i = 0, l-1 do
			SVPNG_PUT( ua[i] )
		end 
	end 
	local function SVPNG_U32(u)
		SVPNG_PUT( bit.rshift(u, 24) )
		SVPNG_PUT( bit.band(bit.rshift(u, 16), 0xff) )
		SVPNG_PUT( bit.band(bit.rshift(u, 8), 0xff) )
		SVPNG_PUT( bit.band(u, 0xff) )
	end
	local function SVPNG_U8C(u)
		SVPNG_PUT(u)
		c[0] = bit.bxor(c[0], u)
		c[0] = bit.bxor((bit.rshift(c[0], 4)), t[ bit.band(c[0], 15) + 1])
		c[0] = bit.bxor(bit.rshift(c[0], 4), t[ bit.band(c[0], 15) + 1])
	end 
	local function SVPNG_U8AC(ua, l) 
		for i = 0, l-1 do SVPNG_U8C(ua[i]) end
	end
	local function SVPNG_U16LC(u) 
		SVPNG_U8C(bit.band(u, 255))
		SVPNG_U8C(bit.band(bit.rshift(u, 8), 255 ) )
	end
	local function SVPNG_U32C(u) 
		SVPNG_U8C( bit.rshift(u, 24) )
		SVPNG_U8C( bit.band(bit.rshift( u, 16), 255) )
		SVPNG_U8C( bit.band(bit.rshift( u, 8), 255) )
		SVPNG_U8C( bit.band(u, 255) )
	end
	local function SVPNG_U8ADLER(u)
		SVPNG_U8C(u)
		a[0] = (a[0] + u) % 65521
		b[0] = (b[0] + a[0]) % 65521
	end
	local function SVPNG_BEGIN(s, l) 
		SVPNG_U32(l)
		c[0] = bit.bnot(0)
		SVPNG_U8AC(s, 4)
	end
	local function SVPNG_END() 
		SVPNG_U32(bit.bnot(c[0]))
	end

	local depth = 2
	if(mode == 4) then depth = 6 end

    SVPNG_U8A(ffi.new("uint8_t[8]", { 0x89, bt"P", bt"N", bt"G", bt"\r", bt"\n", 0x1a, bt"\n" }), 8)			-- /* Magic */
    SVPNG_BEGIN(ffi.new("uint8_t[13]",{ bt"I", bt"H", bt"D", bt"R" }), 13)						-- /* IHDR chunk { */
	SVPNG_U32C(w)
    SVPNG_U32C(h)
    SVPNG_U8C(8)
	SVPNG_U8C(depth)							-- /*   Depth=8, Color=True color with/without alpha (2 bytes) */
    SVPNG_U8AC(ffi.new("uint8_t[3]",{ 0, 0, 0 }), 3) 					-- /*   Compression=Deflate, Filter=No, Interlace=No (3 bytes) */
    SVPNG_END()									-- /* } */
    SVPNG_BEGIN(ffi.new("uint8_t[4]", { bt"I", bt"D", bt"A", bt"T" }), 2 + h * (5 + p[0]) + 4)	-- /* IDAT chunk { */
    SVPNG_U8AC(ffi.new("uint8_t[2]",{ 0x78, bt"\1"}), 2)						-- /*   Deflate block begin (2 bytes) */
    local iptr = 0
	for y = 0, h-1 do							-- /*   Each horizontal line makes a block for simplicity */
		local last = 0
		if(y == h) then last = 1 end
        SVPNG_U8C(last)					-- /*   1 for the last block, 0 for others (1 byte) */
        SVPNG_U16LC(p[0]) 
		SVPNG_U16LC(bit.bnot(p[0]))							-- /*   Size of block in little endian and its 1's complement (4 bytes) */
        SVPNG_U8ADLER(0)						-- /*   No filter prefix (1 byte) */
        for x = 0, p[0] - 2 do
            SVPNG_U8ADLER(img[iptr])				-- /*   Image pixel data */
			iptr = iptr + 1
		end
	end 
    SVPNG_U32C(bit.bor(bit.rshift(b[0], 16), a[0]) )	-- /*   Deflate block end with adler (4 bytes) */
    SVPNG_END()									-- /* } */
    SVPNG_BEGIN(ffi.new("uint8_t[4]","IEND"), 0)
	SVPNG_END()									-- /* IEND chunk {} */
end


local function test(width, height, depth)

	local img = ffi.new("uint8_t[?]", width * height * depth, 128)
	local fh = io.open("test.png", "wb")
	if(fh) then 
		svpng( fh, width, height, img, depth )
		fh:close()
	end 
end

-- test(220, 24, 3)