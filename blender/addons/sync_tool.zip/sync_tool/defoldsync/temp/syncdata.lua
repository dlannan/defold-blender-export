return {
OBJECTS = { 
["COLL_Collection"] = { 
["Light"] = {['name']="Light", ['type']="LIGHT", ['location']={['x']=4.076245307922363, ['y']=1.0054539442062378, ['z']=5.903861999511719}, ['rotation']={['quat']={['x']=0.16907575726509094, ['y']=0.27217137813568115, ['z']=0.7558803558349609, ['w']=0.570947527885437}, ['euler']={['x']=0.6503279805183411, ['y']=0.055217113345861435, ['z']=1.8663908243179321}}, ['scaling']={['x']=1.0, ['y']=1.0, ['z']=1.0}}, 
["Camera"] = {['name']="Camera", ['type']="CAMERA", ['location']={['x']=5.527342796325684, ['y']=-8.328495025634766, ['z']=5.168280124664307}, ['rotation']={['quat']={['x']=0.4957674741744995, ['y']=0.14917106926441193, ['z']=0.2465081661939621, ['w']=0.8192657232284546}, ['euler']={['x']=1.0883753299713135, ['y']=4.083162608026214e-08, ['z']=0.5845446586608887}}, ['scaling']={['x']=1.0, ['y']=1.0, ['z']=1.0}}, 
["entity0_brush0"] = {['name']="entity0_brush0", ['type']="MESH", ['location']={['x']=0.0, ['y']=0.0, ['z']=0.0}, ['rotation']={['quat']={['x']=0.7071068286895752, ['y']=0.0, ['z']=0.0, ['w']=0.7071067094802856}, ['euler']={['x']=1.5707964897155762, ['y']=-0.0, ['z']=0.0}}, ['scaling']={['x']=1.0, ['y']=1.0, ['z']=1.0}}, 
["entity0_brush1"] = {['name']="entity0_brush1", ['type']="MESH", ['location']={['x']=0.0, ['y']=0.0, ['z']=0.0}, ['rotation']={['quat']={['x']=0.7071068286895752, ['y']=0.0, ['z']=0.0, ['w']=0.7071067094802856}, ['euler']={['x']=1.5707964897155762, ['y']=-0.0, ['z']=0.0}}, ['scaling']={['x']=1.0, ['y']=1.0, ['z']=1.0}}, 
["entity0_brush2"] = {['name']="entity0_brush2", ['type']="MESH", ['location']={['x']=0.0, ['y']=0.0, ['z']=0.0}, ['rotation']={['quat']={['x']=0.7071068286895752, ['y']=0.0, ['z']=0.0, ['w']=0.7071067094802856}, ['euler']={['x']=1.5707964897155762, ['y']=-0.0, ['z']=0.0}}, ['scaling']={['x']=1.0, ['y']=1.0, ['z']=1.0}}, 
}, 
} 
, 
MESHES = { 
["entity0_brush0"] = "/Users/davidlannan/Library/Application Support/Blender/2.83/scripts/addons/sync_tool/defoldsync/temp/entity0_brush0.json", 
["entity0_brush1"] = "/Users/davidlannan/Library/Application Support/Blender/2.83/scripts/addons/sync_tool/defoldsync/temp/entity0_brush1.json", 
["entity0_brush2"] = "/Users/davidlannan/Library/Application Support/Blender/2.83/scripts/addons/sync_tool/defoldsync/temp/entity0_brush2.json", 
} 
, 
}
