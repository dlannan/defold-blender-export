-- Lua generated config - do not edit.
return {
   sync_mode        = "Sync Build",
   sync_proj        = "F:\\dev\\defold\\repos\\f18",
   sync_scene       = "sf-map",
   sync_shader      = "Model Material",
   sync_light_mode  = "Flat Shade",
   sync_light_vec   = { x = 0.0, y = -1.0, z = 0.0 },
   sync_mat_params   = { x = 0.10000000149011612, y = 1.0, z = 0.5 },
   sync_mat_facenormals = false,
   sync_mat_uv2     = false,
   stream_info      = false,
   stream_object    = true,
   stream_mesh      = true,
   stream_mesh_type = "gltf",
   stream_anim      = false,
   stream_anim_name = "",
}
